from django.test import TestCase

from test_data import *
# Create your tests here.
